<?php
if(isset($_SESSION['email'])){
  
}
else{ 
  header('location:Login.php');
}
?>