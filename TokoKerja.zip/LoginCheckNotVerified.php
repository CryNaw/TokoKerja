<?php

?>

<html>
  <body>
    <div class="row justify-content-center">
      <div class="col-8">
        Please Verify Your Email
        Check Your Mailbox.
      </div>
    </div>
  </body>
</html>